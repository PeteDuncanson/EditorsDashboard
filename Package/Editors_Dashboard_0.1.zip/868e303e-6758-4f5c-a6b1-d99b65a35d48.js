﻿angular.module("umbraco").controller("Our.Umbraco.EditorsDashboard.DashboardController", [

	"$scope",
	"$rootScope",
	"$window",
    "dialogService",
    "notificationsService",
	"Our.Umbraco.EditorsDashboard.Resources",

	function ($scope, $rootScope, $window, dialogService, notificationsService, buaResources) {

	    

	}

]);

angular.module("umbraco").controller("Our.Umbraco.EditorsDashboard.DialogController", [

    "$scope",
    "$rootScope",
    "Our.Umbraco.EditorsDashboard.Resources",

    function($scope, $rootScope, buaResources) {

        

    }

]);